<?php

$beanList["Gluussos"] = "Gluussos";

$beanFiles["Gluussos"] = "modules/Gluussos/Gluussos.php";

$moduleList[] = "Gluussos";

?>